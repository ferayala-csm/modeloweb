<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css"/>

    <title>Ventas</title>
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="media/logo.png" alt="Logo" height="40">
        </div>

        <div class="datosUsuario">
            <div class="usuario-info">
                <img src="media/usuarios.png" alt="Logo" height="30">
                <label for="usuario">Usuario:</label>
                <div class="usuario" id="usuario"></div>
            </div>
            <label for="caja">Caja:</label>
            <div class="caja" id="caja"></div>
        </div>

        <div class="nav-buttons">
            
            <button id="inicioBtn">Inicio</button>
            <button id="articulosBtn">Artículos</button>
            <button id="ventasBtn">Ventas</button>
            <button id="comprasBtn">Compras</button>
            <button id="clientesBtn">Clientes</button>
            <button id="proveedoresBtn">Proveedores</button>
            <button id="usuariosBtn">Usuarios</button>
            <button>Cerrar sesión</button>
            <button class="pantallacompleta" id="fullscreen-btn"></button>
            
        </div>
        

    </div>
    <div class="content" id="paginaInicio">

        <div class="tarjetas">
            <div id="articulos" class="card" style="background-image: url(media/articulos.png);">
                <div class="gradient"></div>
                <div class="info2">
                    <div class="titulo2">ARTICULOS</div>
                </div>
            </div>
            <div id="ventas" class="card" style="background-image: url(media/ventas.png);">
                <div class="gradient" style="background-image: linear-gradient(0deg, #5ae01188, transparent);"></div>
                <div class="info2">
                    <div class="titulo2">VENTAS</div>
                </div>
            </div>
            <div id="compras" class="card" style="background-image: url(media/compras.png);">
                <div class="gradient" style="background-image: linear-gradient(0deg, red, transparent);"></div>
                <div class="info2">
                    <div class="titulo2">COMPRAS</div>
                </div>
            </div>
            <div id="clientes" class="card" style="background-image: url(media/clientes.png);">
                <div class="gradient" style="background-image: linear-gradient(0deg, #0703fa, transparent);"></div>
                <div class="info2">
                    <div class="titulo2">CLIENTES</div>
                </div>
            </div>
            <div id="proveedores" class="card" style="background-image: url(media/proveedores.png);">
                <div class="gradient" style="background-image: linear-gradient(0deg, yellow, transparent);"></div>
                <div class="info2">
                    <div class="titulo2">PROVEEDORES</div>
                </div>
            </div>
            <div id="usuarios" class="card" style="background-image: url(media/usuarios.png);">
                <div class="gradient" style="background-image: linear-gradient(0deg, orange, transparent);"></div>
                <div class="info2">
                    <div class="titulo2">USUARIOS</div>
                </div>
            </div>
        </div>


            <div class="contenedor">
                <div class="burbujas">
                    <span style="--i:11;"></span>
                    <span style="--i:12;"></span>
                    <span style="--i:24;"></span>
                    <span style="--i:10;"></span>
                    <span style="--i:14;"></span>
                    <span style="--i:23;"></span>
                    <span style="--i:8;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:9;"></span>
                    <span style="--i:20;"></span>
                    <span style="--i:11;"></span>
                    <span style="--i:5;"></span>
                    <span style="--i:18;"></span>
                    <span style="--i:21;"></span>
                    <span style="--i:15;"></span>
                    <span style="--i:13;"></span>
                    <span style="--i:6;"></span>
                    <span style="--i:17;"></span>
                    <span style="--i:8;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:11;"></span>
                    <span style="--i:12;"></span>
                    <span style="--i:24;"></span>
                    <span style="--i:10;"></span>
                    <span style="--i:14;"></span>
                    <span style="--i:20;"></span>
                    <span style="--i:5;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:9;"></span>
                    <span style="--i:20;"></span>
                    <span style="--i:22;"></span>
                    <span style="--i:11;"></span>
                    <span style="--i:18;"></span>
                    <span style="--i:12;"></span>
                    <span style="--i:20;"></span>
                    <span style="--i:10;"></span>
                    <span style="--i:21;"></span>
                    <span style="--i:15;"></span>
                    <span style="--i:9;"></span>                    
                    <span style="--i:8;"></span>
                    <span style="--i:12;"></span>
                    <span style="--i:24;"></span>
                    <span style="--i:10;"></span>
                    <span style="--i:14;"></span>
                    <span style="--i:23;"></span>
                    <span style="--i:18;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:19;"></span>
                    <span style="--i:20;"></span>
                    <span style="--i:22;"></span>
                    <span style="--i:5;"></span>
                    <span style="--i:8;"></span>
                    <span style="--i:21;"></span>
                    <span style="--i:15;"></span>
                    <span style="--i:13;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:7;"></span>
                    <span style="--i:13;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:11;"></span>
                    <span style="--i:12;"></span>
                    <span style="--i:24;"></span>
                    <span style="--i:10;"></span>
                    <span style="--i:14;"></span>
                    <span style="--i:23;"></span>
                    <span style="--i:18;"></span>
                    <span style="--i:16;"></span>
                    <span style="--i:19;"></span>
                    <span style="--i:20;"></span>
                    <span style="--i:12;"></span>
                    <span style="--i:5;"></span>
                    <span style="--i:8;"></span>
                    <span style="--i:22;"></span>
                    <span style="--i:15;"></span>
                    <span style="--i:18;"></span>
                    <span style="--i:11;"></span>
                    <span style="--i:15;"></span>
                    <span style="--i:13;"></span>
                </div>
            </div>
            
            
            <footer class="footer">
                Prime Main WEB &copy; 2024
            </footer>

    </div>
    <div class="content" id="ventasContent">
        <div class="grid-container">
        
            

            <div class="grid" id="productGrid">
                <button id="filtro1" class="filtro" data-filtro="panes">Panes</button>
                <button id="filtro2" class="filtro" data-filtro="verduras">Verduras</button>
                <button id="filtro3" class="filtro" data-filtro="frutas">Frutas</button>
                <button id="filtro4" class="filtro" data-filtro="lacteos">Lácteos</button>
                <button id="filtro5" class="filtro" data-filtro="bebidas">Bebidas</button>
                <button id="filtro6" class="filtro" data-filtro="snacks">Snacks</button>
                <button id="filtro7" class="filtro" data-filtro="carnes">Carnes</button>
                <button id="filtro8" class="filtro" data-filtro="limpieza">Productos de limpieza</button>
                <button id="filtro9" class="filtro" data-filtro="cuidado">Productos de cuidado personal</button>
            </div>

            <div>
                <div class="datos-cliente">
                    <label class="titulo">Datos del cliente</label>
                                            <div>
                                                <label for="cliente">Sr/a:</label>
                                                <input type="text" placeholder="-Cliente ocacional-" id="cliente">
                                            </div>
                                            <div>
                                                <label for="telefono">Teléfono:</label>
                                                <input type="text" id="telefono">
                                            </div>
                                            <div>
                                                <label for="domicilio">Domicilio:</label>
                                                <input type="text" id="domicilio">
                                            </div>
                                            <div>
                                                <label for="email">E-mail:</label>
                                                <input type="text" id="email">
                                            </div>
                                            <div>
                                                <label for="condicionIVA">Condición IVA:</label>
                                                <select id="condicionIVA">
                                                <option value="consumidor-final" selected>Consumidor Final</option>
                                                <option value="monotributista">Monotributista</option>
                                                <option value="exento">Exento</option>
                                                <option value="otro">Otro</option>
                                                </select>
                                                
                                            </div>
                                            
                    
                </div>
            </div>
            
            <div>
                <div class="info" id="infoProduct">
                    
                    <div class="prod" id="nombreProducto"></div>
                    <div id="idProducto"></div>
                    <div id="codigoProducto"></div>
                    <div id="precioProducto"></div>
                    <div id="stockProducto"></div>
                    <div id="ultimoProducto"></div>
                    <div class="colormensaje" id="mensaje"></div>
            
                </div>
            </div>

        </div>
        <div class="table-container">
            <h1 style="text-align: center;">Lista de Productos</h1>
            <div class="table-wrapper">
                <table id="tablaProductos">
                    <thead>
                        <tr>
                            <th>Artículo</th>
                            <th>Stock</th>
                            <th>Precio unitario</th>
                            <th>Cantidad</th>
                            <th>Des/Rec</th>
                            <th>Importe</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Las filas de productos se agregarán dinámicamente aquí -->
                    </tbody>
                </table>
            </div>
            <div class="opciones">
                <img src="media/parrafo1.png" alt="Parrafo1" height="30">
                <button class="quitar" id="quitar" >Quitar</button>
                <button class="descuento" id="descuento">Descuento</button>
                <button class="recargo" id="recargo">Recargo</button>
                <button class="cambiar-cantidad" id="cambiar-cantidad">Cambiar cantidad </button>
                <button class="cambiar-precio" id="cambiar-precio">Cambiar precio</button>
            </div>
        </div>
        <div class="input-container">
            <input type="text" id="producto">
            <input type="text" id="precio">
            <input type="text" placeholder="Código de barra" id="codigo" onblur="buscarArticuloPorCodigo()" oninput="buscarArticuloPorCodigo()">
            <input type="text" placeholder="Buscar producto" id="palabras" >

            <div id="otroContexto">
            <label for="cantidadProducto">Cantidad:</label>
            <input type="number" id="cantidadProducto" min="1" value="1">
            </div>
            <input id="inputButton" type="button" value="Agregar" >
            <div class="descripcion">
            <p><strong>Subtotal:</strong> $<span id="subtotal">0.00</span></p>
            <p><strong id="vista">Descuento/Recargo:</strong> $<span id="descuentoRecargo">0.00</span></p>
            <p><strong>Total:</strong> $<span id="total" class="total">0.00</span></p>
            </div>
            <div class="general">
            <img src="media/parrafo2.png" alt="Parrafo1" height="30">
            <button class="descuento-recargo" id="descuento-recargo">Descuento/Recargo</button>
            <select id="metodoPago">
            <option value="efectivo" selected>Efectivo</option>
            <option value="tarjetaDebito">Tarjeta de Débito</option>
            <option value="tarjetaCredito">Tarjeta de Crédito</option>
            <option value="transferencia">Transferencia</option>
            <option value="otro">Otro</option>
            </select>
            </div>
            <div class="cobrar">
            <button class="cobrar" id="cobrar" >COBRAR</button>
            </div>
        </div>
    

        <div class="comprobante" id="datosComprobante">
            <label class="titulo">Datos del comprobante</label>
            <div class="factura">
            <div>
                                                    <label for="fecha">Fecha:</label>
                                                    <input type="date" id="fecha">
                                                
                                                    <label for="tipo-ticket">Tipo:</label>
                                                    <select id="tipo-ticket">
                                                    <option value="ticket-fiscal" selected>Ticket Fiscal</option>
                                                    <option value="fsctura-b">Factura B</option>
                                                    <option value="factura-a">Factura A</option>
                                                    <option value="otro">Otro</option>
                                                    </select>
                                                    
                                                
                                                    <label for="numero">Nro:</label>
                                                    <input type="text" id="numero">
                                                </div>
                                                
                                                <div>
                                                    <label for="descripcion">Descripcion:</label>
                                                    <input type="text" id="descripcion">
                                                    <button class="ver" id="ver-comprobante">ver comprobante</button>
                                                </div>

            </div>
        </div>

        

    </div>
    <div class="related-products" id="relatedProducts">
            <?php
                // Generar botones vacíos
                for ($i = 1; $i <= 24; $i++) {
                    echo "<button class='resultado'></button>";
                }
                ?>
    </div>
    <div class="content" id="articulosContent">
        <p>Este es el contenido de artículos.</p>
    </div>
    <div class="content" id="comprasContent">
        <p>Este es el contenido de compras.</p>
    </div>
    <div class="content" id="clientesContent">
        <p>Este es el contenido de clientes.</p>
    </div>
    <div class="content" id="proveedoresContent">
        <p>Este es el contenido de proveedores.</p>
    </div>
    <div class="content" id="usuariosContent">
        <p>Este es el contenido de usuarios.</p>
    </div>
    

    <script>
        //pantalla completaVentas
        document.getElementById('fullscreen-btn').addEventListener('click', function() {
            const elem = document.documentElement;

            if (!document.fullscreenElement) {
                if (elem.requestFullscreen) {
                    elem.requestFullscreen();
                } else if (elem.mozRequestFullScreen) { // Firefox
                    elem.mozRequestFullScreen();
                } else if (elem.webkitRequestFullscreen) { // Chrome, Safari and Opera
                    elem.webkitRequestFullscreen();
                } else if (elem.msRequestFullscreen) { // IE/Edge
                    elem.msRequestFullscreen();
                }
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.mozCancelFullScreen) { // Firefox
                    document.mozCancelFullScreen();
                } else if (document.webkitExitFullscreen) { // Chrome, Safari and Opera
                    document.webkitExitFullscreen();
                } else if (document.msExitFullscreen) { // IE/Edge
                    document.msExitFullscreen();
                }
            }
        });

        //por defecto empieza inicio
        showOnly(['paginaInicio']);
        // Mostrar contenido de Ventas y productos relacionados
        function showOnly(sectionIds) {
            // Hide all content sections and related products
            const allSections = document.querySelectorAll('.content, .related-products');
            allSections.forEach(section => section.classList.remove('show'));

            // Show the specified sections
            sectionIds.forEach(id => {
                const section = document.getElementById(id);
                if (section) {
                    section.classList.add('show');
                }
            });
        }
        //botones para navegar en inicio
                document.getElementById('inicioBtn').addEventListener('click', function() {
                    showOnly(['paginaInicio']);
                });

                document.getElementById('articulosBtn').addEventListener('click', function() {
                    showOnly(['articulosContent']);
                    });
                    document.getElementById('articulos').addEventListener('click', function() {
                        showOnly(['articulosContent']);
                });

                document.getElementById('ventasBtn').addEventListener('click', function() {
                    showOnly(['ventasContent']);
                    });
                    document.getElementById('ventas').addEventListener('click', function() {
                        showOnly(['ventasContent']);
                });

                document.getElementById('comprasBtn').addEventListener('click', function() {
                    showOnly(['comprasContent']);
                    });
                    document.getElementById('compras').addEventListener('click', function() {
                        showOnly(['comprasContent']);
                });

                document.getElementById('clientesBtn').addEventListener('click', function() {
                    showOnly(['clientesContent']);
                    });
                    document.getElementById('clientes').addEventListener('click', function() {
                        showOnly(['clientesContent']);
                });

                document.getElementById('proveedoresBtn').addEventListener('click', function() {
                    showOnly(['proveedoresContent']);
                    });
                    document.getElementById('proveedores').addEventListener('click', function() {
                        showOnly(['proveedoresContent']);
                });

                document.getElementById('usuariosBtn').addEventListener('click', function() {
                    showOnly(['usuariosContent']);
                    });
                    document.getElementById('usuarios').addEventListener('click', function() {
                        showOnly(['usuariosContent']);
                });
                //para que aparezcan los products relacionados al precionar los botones del filtro
                    document.getElementById('filtro1').addEventListener('click', function() {
                        showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro2').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro3').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro4').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro5').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro6').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro7').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro8').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                        });
                        document.getElementById('filtro9').addEventListener('click', function() {
                            showOnly(['relatedProducts','ventasContent']);
                    });
        //fin botones navegacion



        // COMIENZO A AGREGAR FUNCIONES DE LA PARTE DE VENTAS

            let valorDescuentoRecargo = 0;
            let currentGridIndex = 0;
            const itemsPerPage = 9;
            const productGrid = document.getElementById('productGrid');
            const gridItems = Array.from(productGrid.children);
            function updateGrid() {
                gridItems.forEach((item, index) => {
                    if (index >= currentGridIndex * itemsPerPage && index < (currentGridIndex + 1) * itemsPerPage) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            }

            function prevGrid() {
                if (currentGridIndex > 0) {
                    currentGridIndex--;
                    updateGrid();
                }
            }

            function nextGrid() {
                if ((currentGridIndex + 1) * itemsPerPage < gridItems.length) {
                    currentGridIndex++;
                    updateGrid();
                }
            }
            updateGrid();


            //para la fecha del comprobante
            document.addEventListener("DOMContentLoaded", function() {
                var today = new Date().toISOString().split('T')[0];
                document.getElementById('fecha').value = today;
            });


            // Evento al hacer clic en los botones de filtro
            const filtros = document.querySelectorAll('.filtro');
            filtros.forEach(filtro => {
                filtro.addEventListener('click', () => {
                    const filtroValor = filtro.getAttribute('data-filtro');
                    console.log("Clic en filtro:", filtroValor);
                    cargarResultados(filtroValor); // Llama a cargarResultados con el filtro seleccionado
                });
            });
            document.addEventListener('DOMContentLoaded', function() {
                    // Agregar eventos después de que el DOM se haya cargado completamente
                    const inputPalabras = document.getElementById('palabras');
            // Manejar el evento de teclado para la búsqueda
                inputPalabras.addEventListener('keydown', (event) => {
                    if (event.key === 'Enter') {
                        fetchProductInfo();
                    }
                });
            
            });
            
                    // Función para seleccionar una fila
                    function seleccionarFila(fila) {
                        // Remover la clase 'seleccionada' de todas las filas
                        const filas = document.querySelectorAll('#tablaProductos tbody tr');
                        filas.forEach(function(fila) {
                            fila.classList.remove('seleccionada');
                        });

                        // Agregar la clase 'seleccionada' a la fila clickeada
                        fila.classList.add('seleccionada');
                    }

                    // Función para eliminar la fila seleccionada
                        function eliminarFilaSeleccionada() {
                            const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
                            if (filaSeleccionada) {
                                filaSeleccionada.remove();
                                actualizarTotalVenta();
                            } else {
                                alert("No hay ninguna fila seleccionada.");
                            }
                        }
                        
                        document.addEventListener('DOMContentLoaded', function() {
                            const quitarButton = document.getElementById('quitar');
                            quitarButton.addEventListener('click', eliminarFilaSeleccionada);

                            const filas = document.querySelectorAll('#tablaProductos tbody tr');
                            filas.forEach(function(fila) {
                                fila.addEventListener('click', function() {
                                    seleccionarFila(this);
                                });
                            });
                        });
                    //botones de la tabla
                        document.addEventListener('DOMContentLoaded', function() {
                        let descuentos = {};
                        let recargos = {};

                        function abrirModal(modalId) {
                            const modal = document.getElementById(modalId);
                            modal.style.display = 'block';

                            window.onclick = function(event) {
                                if (event.target == modal) {
                                    modal.style.display = 'none';
                                }
                            }
                        }

                        function cerrarModal() {
                            const modals = document.querySelectorAll('.modal');
                            modals.forEach(modal => modal.style.display = 'none');
                        }

                        function actualizarFila(filaSeleccionada, tipo, valor) {
                            if (filaSeleccionada) {
                                const filaIndex = Array.from(filaSeleccionada.parentNode.children).indexOf(filaSeleccionada);
                                let precioUnitario = parseFloat(filaSeleccionada.cells[2].textContent);
                                let cantidad = parseInt(filaSeleccionada.cells[3].textContent);

                                if (tipo === 'descuento') {
                                    const descuento = parseFloat(valor) / 100;
                                    descuentos[filaIndex] = descuento;
                                    filaSeleccionada.cells[4].innerHTML = '<span style="color: red;">-' + (descuento * 100).toFixed(2) + '%</span>';
                                } else if (tipo === 'recargo') {
                                    const recargo = parseFloat(valor) / 100;
                                    recargos[filaIndex] = recargo;
                                    filaSeleccionada.cells[4].innerHTML = '<span style="color: green;">+' + (recargo * 100).toFixed(2) + '%</span>';
                                } else if (tipo === 'cantidad') {
                                    cantidad = parseInt(valor);
                                    filaSeleccionada.cells[3].textContent = cantidad;
                                } else if (tipo === 'precio') {
                                    precioUnitario = parseFloat(valor);
                                    filaSeleccionada.cells[2].textContent = precioUnitario.toFixed(2);
                                }

                                const descuento = descuentos[filaIndex] || 0;
                                const recargo = recargos[filaIndex] || 0;
                                let nuevoImporte;

                                if (descuento > 0) {
                                    nuevoImporte = precioUnitario * cantidad * (1 - descuento);
                                } else if (recargo > 0) {
                                    nuevoImporte = precioUnitario * cantidad * (1 + recargo);
                                } else {
                                    nuevoImporte = precioUnitario * cantidad;
                                }

                                filaSeleccionada.cells[5].textContent = nuevoImporte.toFixed(2);

                                actualizarTotalVenta(valorDescuentoRecargo);
                            }
                        }

                        document.querySelectorAll('.close').forEach(span => {
                            span.onclick = cerrarModal;
                        });

                        document.getElementById('guardarDescuentoBtn').addEventListener('click', function() {
                            const descuentoInput = document.getElementById('descuentoInput').value;
                            if (descuentoInput) {
                                const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
                                actualizarFila(filaSeleccionada, 'descuento', descuentoInput);
                                cerrarModal();
                            }
                        });

                        document.getElementById('guardarRecargoBtn').addEventListener('click', function() {
                            const recargoInput = document.getElementById('recargoInput').value;
                            if (recargoInput) {
                                const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
                                actualizarFila(filaSeleccionada, 'recargo', recargoInput);
                                cerrarModal();
                            }
                        });

                        document.getElementById('guardarCantidadBtn').addEventListener('click', function() {
                            const cantidadInput = document.getElementById('cantidadInput').value;
                            if (cantidadInput) {
                                const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
                                actualizarFila(filaSeleccionada, 'cantidad', cantidadInput);
                                cerrarModal();
                            }
                        });

                        document.getElementById('guardarPrecioBtn').addEventListener('click', function() {
                            const precioInput = document.getElementById('precioInput').value;
                            if (precioInput) {
                                const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
                                actualizarFila(filaSeleccionada, 'precio', precioInput);
                                cerrarModal();
                            }
                        });

                        function seleccionarFilaYAbrirModal(botonId, modalId, inputId, celdaIndex) {
                            const boton = document.getElementById(botonId);
                            boton.addEventListener('click', function() {
                                const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
                                if (filaSeleccionada) {
                                    abrirModal(modalId);
                                    const valorActual = filaSeleccionada.cells[celdaIndex].textContent;
                                    document.getElementById(inputId).value = parseFloat(valorActual) || 0;
                                } else {
                                    alert("No hay ninguna fila seleccionada.");
                                }
                            });
                        }

                        seleccionarFilaYAbrirModal('descuento', 'descuentoModal', 'descuentoInput', 4);
                        seleccionarFilaYAbrirModal('recargo', 'recargoModal', 'recargoInput', 4);
                        seleccionarFilaYAbrirModal('cambiar-cantidad', 'cantidadModal', 'cantidadInput', 3);
                        seleccionarFilaYAbrirModal('cambiar-precio', 'precioModal', 'precioInput', 2);
                    });




            // Función para cargar los resultados de la búsqueda según el filtro
            function cargarResultados(filtro) {
                console.log("Cargar resultados para filtro:", filtro);
                // Hacer una solicitud AJAX para obtener los resultados de la búsqueda
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "php/buscar_articulos.php?filtro=" + filtro, true);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        console.log("Respuesta recibida:", xhr.responseText);
                        // Parsear la respuesta JSON
                        const resultados = JSON.parse(xhr.responseText);
                        console.log("Resultados parseados:", resultados);

                        // Limpiar el contenido actual de productos relacionados
                        const relatedProducts = document.querySelectorAll('.related-products .resultado');
                        relatedProducts.forEach(boton => {
                            boton.textContent = '';
                            boton.dataset.producto = '';
                        });

                        // Llenar los botones de productos relacionados con los resultados
                        resultados.forEach((resultado, index) => {
                            if (index < relatedProducts.length) { // Mostrar hasta 20 productos relacionados
                                relatedProducts[index].textContent = resultado.articulo;
                                relatedProducts[index].dataset.producto = JSON.stringify(resultado);

                                // Agregar evento clic a cada botón de producto relacionado
                                relatedProducts[index].addEventListener('click', function() {
                                    mostrarVistaPrevia(resultado);
                                });
                            }
                        });
                    }
                };
                xhr.send();
            }

            // Función para buscar información del producto
            function fetchProductInfo(keyword) {
                const palabras = document.getElementById('palabras').value.trim();
                if (palabras !== '') {
                    // Hacer una solicitud AJAX para buscar el artículo por palabra clave
                    const xhr = new XMLHttpRequest();
                    xhr.open("GET", "php/buscar_descripcion.php?keyword=" + encodeURIComponent(palabras), true);
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState == 4 && xhr.status == 200) {
                            const productos = JSON.parse(xhr.responseText);
                            if (productos.length > 0) {
                                // Mostrar la vista previa del primer producto encontrado
                                
                                
                                // Mostrar los resultados en el modal
                                mostrarResultadosEnModal(productos);
                                document.getElementById('codigo').value = '';
                                document.getElementById('palabras').value = '';

                            } else {
                                // Limpiar la vista previa si no se encuentra ningún producto
                                document.getElementById('mensaje').textContent = "Producto no encontrado";

                                // Establecer un temporizador para limpiar el contenido del mensaje después de 1 segundo (1000 milisegundos)
                                setTimeout(function() {
                                    document.getElementById('mensaje').textContent = "";
                                }, 1000);
                                limpiarVistaPrevia();
                                document.getElementById('codigo').value = '';
                                document.getElementById('palabras').value = '';
                            }
                        }
                    };
                    xhr.send();
                }
            }

            function mostrarResultadosEnModal(productos) {
                const listaArticulos = document.getElementById('listaArticulos');
                listaArticulos.innerHTML = ''; // Limpiar lista actual

                // Crear la tabla y su cabecera
                const table = document.createElement('table');
                table.className = 'result-table';

                const thead = document.createElement('thead');
                const headerRow = document.createElement('tr');

                const headers = ['Código', 'Artículo', 'Precio']; // Agrega más headers según tus necesidades
                headers.forEach(headerText => {
                    const header = document.createElement('th');
                    header.textContent = headerText;
                    headerRow.appendChild(header);
                });
                thead.appendChild(headerRow);
                table.appendChild(thead);

                // Crear el cuerpo de la tabla
                const tbody = document.createElement('tbody');
                productos.forEach(producto => {
                    const row = document.createElement('tr');
                    row.className = 'item-row';

                    // Agregar celdas para cada propiedad del producto
                    const codigoCell = document.createElement('td');
                    codigoCell.textContent = producto.codigo;
                    row.appendChild(codigoCell);

                    const articuloCell = document.createElement('td');
                    articuloCell.textContent = producto.articulo;
                    row.appendChild(articuloCell);

                    const precioCell = document.createElement('td');
                    precioCell.textContent = producto.pventa; // Suponiendo que 'precio' es una propiedad del objeto producto
                    row.appendChild(precioCell);
                            
                    // Agregar evento de clic a la fila
                    row.addEventListener('click', function() {
                       mostrarVistaPrevia(producto);
                       agregarProducto(producto);
                       document.getElementById('palabras').value = '';
                       closeModal();

                    });

                    tbody.appendChild(row);
                });
                table.appendChild(tbody);

                listaArticulos.appendChild(table);

                // Abrir el modal
                document.getElementById('busqueda').style.display = 'block';
            }

                function closeModal() {
                    document.getElementById('busqueda').style.display = 'none';
                }

                

            
            // Evento para el botón de agregar
            document.getElementById('inputButton').addEventListener('click', () => {
                agregarProducto(producto);
                actualizarTotalVenta(valorDescuentoRecargo);
                
            });
            
            // Eventos para los botones de opciones
            const buttons = document.querySelectorAll('.opciones button');
            buttons.forEach(button => {
                button.addEventListener('click', () => {
                    // Lógica para cada opción
                    // Por ejemplo: fetchProductInfo(filtro);
                });
            });

            // Eventos para los botones de productos relacionados
            const relatedProductButtons = document.querySelectorAll('.related-products button');
            relatedProductButtons.forEach(button => {
                button.addEventListener('click', () => {
                    // Lógica para cada producto relacionado
                    // Por ejemplo: fetchProductInfo(keyword);
                });
            });



            // Función para mostrar la vista previa del producto
            function mostrarVistaPrevia(producto) {
                document.getElementById('idProducto').textContent = "ID: " + producto.id;
                document.getElementById('codigoProducto').textContent = "Código: " + producto.codigo;
                document.getElementById('nombreProducto').textContent = "Artículo: " + producto.articulo;
                // Verificar que producto.pventa sea un número antes de formatearlo
                const precio = parseFloat(producto.pventa);
                if (!isNaN(precio)) {
                    document.getElementById('precioProducto').textContent = "Precio: $" + precio.toFixed(2);
                    document.getElementById('precio').value = precio.toFixed(2);
                } else {
                    document.getElementById('precioProducto').textContent = "Precio: N/A";
                    document.getElementById('precio').value = "";
                }
                document.getElementById('stockProducto').textContent = "Stock: " + producto.stock;

                document.getElementById('producto').value = producto.articulo;
                document.getElementById('precio').value = producto.pventa;
                document.getElementById('codigo').value = producto.codigo;
            }
            
            function buscarArticuloPorCodigo() {
                const codigo = document.getElementById('codigo').value.trim();
                if (codigo !== '') {
                    // Hacer una solicitud AJAX para buscar el artículo por código
                    const xhr = new XMLHttpRequest();
                    xhr.open("GET", "php/barra.php?codigo=" + codigo, true);
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState == 4 && xhr.status == 200) {
                            const producto = JSON.parse(xhr.responseText);
                            if (producto) {
                                // Mostrar la vista previa del producto encontrado
                                
                                mostrarVistaPrevia(producto);
                                agregarProducto(producto);
                                limpiarVistaPrevia();
                                
                                
                            } else {
                                // Limpiar la vista previa si no se encuentra ningún producto
                                // Mostrar el mensaje de "Producto no encontrado" en el elemento <div> con ID "mensaje"
                                document.getElementById('mensaje').textContent = "Producto no encontradoooo";

                                // Establecer un temporizador para limpiar el contenido del mensaje después de 1 segundo (1000 milisegundos)
                                setTimeout(function() {
                                    document.getElementById('mensaje').textContent = "";
                                }, 1000);
                                limpiarVistaPrevia();
                                document.getElementById('codigo').value = '';
                            }
                        }
                    };
                    xhr.send();
                }

            }
            function buscarArticuloPorCodigoEnter(event) {
                    if (event.key === 'Enter') {
                        const codigo = document.getElementById('codigo').value;
                        buscarArticuloPorCodigo(codigo); // Cambiado para pasar el código como parámetro
                    }
            }
            function limpiarVistaPrevia() {
                    document.getElementById('idProducto').textContent = "";
                    document.getElementById('codigoProducto').textContent = "";
                    document.getElementById('nombreProducto').textContent = "";
                    document.getElementById('precioProducto').textContent = "";
                    document.getElementById('stockProducto').textContent = "";

                    document.getElementById('producto').value = "";
                    document.getElementById('precio').value = "";
            }
            // Función para agregar un producto a la tabla de productos
            function agregarProducto(producto) {
                const nombreProducto = document.getElementById('nombreProducto').textContent.split(": ")[1];
                const stockProducto = document.getElementById('stockProducto').textContent.split(": ")[1];
                const precioProductoText = document.getElementById('precio').value;
                const precioProductoNum = parseFloat(precioProductoText);

                if (isNaN(precioProductoNum)) {
                    alert("El precio del producto no es válido.");
                    return;
                }

                const cantidad = document.getElementById('cantidadProducto').value;
                if (isNaN(parseInt(cantidad)) || parseInt(cantidad) <= 0) {
                    alert("La cantidad ingresada no es válida.");
                    return;
                }

                const importe = precioProductoNum * parseInt(cantidad);

                const tabla = document.querySelector('table tbody');
                const nuevaFila = tabla.insertRow();

                const celdaNombre = nuevaFila.insertCell();
                celdaNombre.textContent = nombreProducto;

                const celdaStock = nuevaFila.insertCell();
                celdaStock.textContent = stockProducto;

                const celdaPrecio = nuevaFila.insertCell();
                celdaPrecio.textContent = precioProductoNum.toFixed(2);

                const celdaCantidad = nuevaFila.insertCell();
                celdaCantidad.textContent = cantidad;

                const celdaDescuento = nuevaFila.insertCell();
                celdaDescuento.textContent = "No";

                const celdaImporte = nuevaFila.insertCell();
                celdaImporte.textContent = importe.toFixed(2);

                // Añadir evento de clic para seleccionar la fila
                nuevaFila.addEventListener('click', function() {
                    seleccionarFila(this);
                });

                // Actualizar total de la venta
                actualizarTotalVenta(valorDescuentoRecargo, true);

                limpiarVistaPrevia();

                document.getElementById('palabras').value = '';
                document.getElementById('codigo').value = '';

                document.getElementById('cantidadProducto').value = '1';
            }

            

            // Función para actualizar el total de la venta
            function actualizarTotalVenta(valorDescuentoRecargo = 0, incluirDescuentoRecargo = true) {
                const filas = document.querySelectorAll('#tablaProductos tbody tr');
                let subtotal = 0;
                filas.forEach(fila => {
                    const importe = parseFloat(fila.cells[5].textContent);
                    subtotal += importe;
                });

                let total = subtotal;
                if (incluirDescuentoRecargo && valorDescuentoRecargo !== 0) {
                    const montoDescuentoRecargo = subtotal * (Math.abs(valorDescuentoRecargo) / 100);
                    if (valorDescuentoRecargo < 0) {
                        total = subtotal - montoDescuentoRecargo; // descuento es negativo
                    } else {
                        total = subtotal + montoDescuentoRecargo; // recargo es positivo
                    }
                }

                document.getElementById('subtotal').textContent = subtotal.toFixed(2);
                document.getElementById('total').textContent = total.toFixed(2);
            }

            
        // FINAL DE FUNCIONES DE VENTAS


        //COBRARprueba
        document.getElementById('cobrar').addEventListener('click', function() {
            // Recopilar los datos del cliente
            const cliente = document.getElementById('cliente').value.trim() || '-Cliente ocasional-';
            const telefono = document.getElementById('telefono').value.trim() || 'N/A';
            const domicilio = document.getElementById('domicilio').value.trim() || 'N/A';
            const email = document.getElementById('email').value.trim() || 'N/A';
            const condicionIVA = document.getElementById('condicionIVA').value || 'consumidor-final';

            // Recopilar los datos de la venta
            const metodoPago = document.getElementById('metodoPago').value;
            const fecha = document.getElementById('fecha').value;
            const tipoTicket = document.getElementById('tipo-ticket').value;
            const numero = document.getElementById('numero').value.trim() || 'N/A';
            const descripcion = document.getElementById('descripcion').value.trim() || 'N/A';

            // Recopilar los productos de la tabla
            const productos = [];
            document.querySelectorAll('#tablaProductos tbody tr').forEach(tr => {
                const articulo = tr.cells[0].textContent;
                const cantidad = parseInt(tr.cells[3].textContent);
                const precioUnitario = parseFloat(tr.cells[2].textContent);
                const descuentoRecargo = parseFloat(tr.cells[4].textContent) || 0 || valorDescuentoRecargo;
                const importe = parseFloat(tr.cells[5].textContent);

                productos.push({
                    articulo,
                    cantidad,
                    precioUnitario,
                    descuentoRecargo,
                    importe
                });
            });

            // Recopilar el total de la venta
            const total = parseFloat(document.getElementById('total').textContent);

            // Datos del usuario (administrador) y número de caja
            const usuario_id = 2; // Este valor debe ser dinámico según el usuario que ha iniciado sesión
            const caja = 'Caja 1'; // Este valor debe ser dinámico según la caja en uso

            // Preparar los datos para enviar
            const datosVenta = {
                cliente,
                telefono,
                domicilio,
                email,
                condicionIVA,
                metodoPago,
                fecha,
                tipoTicket,
                numero,
                descripcion,
                productos,
                total,
                usuario_id, // Incluir el usuario_id
                caja,
                descuentoRecargo: valorDescuentoRecargo // Incluir el valor de descuento o recargo general
            };

            // Enviar los datos al servidor mediante una solicitud AJAX
            fetch('php/ruta_a_tu_script_de_servidor.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(datosVenta)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Venta realizada con éxito');
                    // Limpiar los campos y la tabla después de realizar la venta
                    document.getElementById('cliente').value = '';
                    document.getElementById('telefono').value = '';
                    document.getElementById('domicilio').value = '';
                    document.getElementById('email').value = '';
                    document.getElementById('condicionIVA').value = 'consumidor-final';
                    document.querySelectorAll('#tablaProductos tbody tr').forEach(tr => tr.remove());
                    document.getElementById('subtotal').textContent = '0.00';
                    document.getElementById('descuentoRecargo').textContent = '0.00';
                    document.getElementById('total').textContent = '0.00';
                } else {
                    alert('Hubo un problema al realizar la venta');
                }
            })
            .catch(error => console.error('Error:', error));
        });

        //COBRARprueba

        //comprobante prueba
                document.getElementById('ver-comprobante').addEventListener('click', function() {
                var cliente = document.getElementById('cliente').value || '-Cliente ocacional-';
                var telefono = document.getElementById('telefono').value || '-';
                var domicilio = document.getElementById('domicilio').value || '-';
                var email = document.getElementById('email').value || '-';
                var condicionIVA = document.getElementById('condicionIVA').value || 'consumidor-final';
                var fecha = document.getElementById('fecha').value || new Date().toISOString().slice(0, 10);
                var tipoTicket = document.getElementById('tipo-ticket').value || 'ticket-fiscal';
                var numero = document.getElementById('numero').value || '-';
                var descripcion = document.getElementById('descripcion').value || '-';
                var subtotal = document.getElementById('subtotal').innerText || '0.00';
                var descuentoRecargo = document.getElementById('descuentoRecargo').innerText || '0.00';
                var total = document.getElementById('total').innerText || '0.00';

                var productos = [];
                var filas = document.querySelectorAll('#tablaProductos tbody tr');
                filas.forEach(function(fila) {
                    var producto = {
                        articulo: fila.cells[0].innerText,
                        precio_unitario: fila.cells[2].innerText,
                        des_rec: fila.cells[4].innerText,
                        importe: fila.cells[5].innerText
                    };
                    productos.push(producto);
                });

                var form = document.createElement('form');
                form.method = 'POST';
                form.action = 'php/mostrar_comprobante.php';
                form.target = '_blank';

                var inputs = {
                    cliente: cliente,
                    telefono: telefono,
                    domicilio: domicilio,
                    email: email,
                    condicionIVA: condicionIVA,
                    fecha: fecha,
                    tipoTicket: tipoTicket,
                    numero: numero,
                    descripcion: descripcion,
                    subtotal: subtotal,
                    descuentoRecargo: descuentoRecargo,
                    total: total,
                    productos: JSON.stringify(productos)
                };

                for (var key in inputs) {
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = key;
                    input.value = inputs[key];
                    form.appendChild(input);
                }

                document.body.appendChild(form);
                form.submit();
            });


        //comprobante

        //descuento/recargo general
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('descuentoRecargoModal');
            const btn = document.getElementById('descuento-recargo');
            const span = document.getElementsByClassName('close')[0];
            const guardarBtn = document.getElementById('guardarDescuentoRecargoBtn');

            // Abre el modal
            btn.onclick = function() {
                modal.style.display = 'block';
            }

            // Cierra el modal
            span.onclick = function() {
                modal.style.display = 'none';
            }

            // Cierra el modal cuando se hace clic fuera del contenido del modal
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }

            // Guarda el descuento/recargo y actualiza la vista previa
            guardarBtn.onclick = function() {
                const valor = parseFloat(document.getElementById('descuentoRecargoInput').value);
                const descuentoRecargoSpan = document.getElementById('descuentoRecargo');
                const vista = document.getElementById('vista');

                if (!isNaN(valor)) {
                    valorDescuentoRecargo = valor;
                    const subtotal = parseFloat(document.getElementById('subtotal').textContent) || 0;
                    const montoDescuentoRecargo = subtotal * (Math.abs(valor) / 100);

                    if (valor < 0) {
                        // Es un descuento
                        vista.textContent = 'Descuento (-%):';
                        descuentoRecargoSpan.textContent = `(${Math.abs(valor).toFixed(2)}%): -$${montoDescuentoRecargo.toFixed(2)}`;
                    } else {
                        // Es un recargo
                        vista.textContent = 'Recargo (+%):';
                        descuentoRecargoSpan.textContent = `(${valor.toFixed(2)}%): +$${montoDescuentoRecargo.toFixed(2)}`;
                    }
                    modal.style.display = 'none';
                    actualizarTotalVenta(valorDescuentoRecargo);  // Pasar el valor para su uso en la función
                    
                } else {
                    alert('Por favor ingrese un valor válido.');
                }
            }
            
            // Llamar a actualizarTotalVenta al cargar la página
            actualizarTotalVenta(valorDescuentoRecargo);


        });
        //descgeneral
        
    </script>
    <div id="descuentoModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            
            <label for="descuentoInput">Descuento (%):</label>
            <input type="number" id="descuentoInput" min="0" max="100" step="0.01">
            <button id="guardarDescuentoBtn">Guardar</button>
        </div>
    </div>
    <div id="recargoModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            
            <label for="recargoInput">Recargo (%):</label>
            <input type="number" id="recargoInput" min="0" max="100" step="0.01">
            <button id="guardarRecargoBtn">Guardar</button>
        </div>
    </div>
    <div id="cantidadModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            
            <label for="cantidadInput">Cantidad:</label>
            <input type="number" id="cantidadInput" min="0" max="100" step="0.01">
            <button id="guardarCantidadBtn">Guardar</button>
        </div>
    </div>
    <div id="precioModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <label for="precioInput">Precio:</label>
            <input type="number" id="precioInput">
            <button id="guardarPrecioBtn">Guardar</button>
        </div>
    </div>
    <div id="busqueda" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="listaArticulos"></div>
        </div>
    </div>
    <div id="descuentoRecargoModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Ingresar Descuento/Recargo</h2>
        <label for="descuentoRecargoInput">Monto:</label>
        <input type="number" id="descuentoRecargoInput" placeholder="Ingrese el monto">
        <button id="guardarDescuentoRecargoBtn">Guardar</button>
    </div>
</div>

</body>
</html>
