<?php
// Realizar la conexión a la base de datos (debes incluir aquí tus credenciales de conexión)
include("conexion/conexion.php");

// Obtener el valor de búsqueda del parámetro GET
$busqueda = $conn->real_escape_string($_GET['busqueda']);

// Construir la consulta SQL para filtrar los artículos por nombre o código
$sql = "SELECT * FROM articulos WHERE articulo LIKE '%$busqueda%' OR codigo LIKE '%$busqueda%'";

// Realizar la consulta a la base de datos
$result = $conn->query($sql);

// Mostrar los resultados en una tabla HTML
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Código</th><th>Artículo</th><th>Precio de costo</th><th>Precio de venta</th><th>Stock</th><th>Stock mínimo</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["codigo"] . "</td>";
        echo "<td>" . $row["articulo"] . "</td>";
        echo "<td>" . $row["pcosto"] . "</td>";
        echo "<td>" . $row["pventa"] . "</td>";
        echo "<td>" . $row["stock"] . "</td>";
        echo "<td>" . $row["minimo"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No se encontraron artículos";
}

// Cerrar la conexión a la base de datos
$conn->close();
?>

