<?php
// Conexión a la base de datos
include("conexion/conexion.php");

// Obtener los datos de la solicitud
$data = json_decode(file_get_contents('php://input'), true);

// Establecer valores predeterminados para los campos vacíos
$data['cliente'] = $data['cliente'] ?: '-Cliente ocasional-';
$data['telefono'] = $data['telefono'] ?: 'N/A';
$data['domicilio'] = $data['domicilio'] ?: 'N/A';
$data['email'] = $data['email'] ?: 'N/A';
$data['condicionIVA'] = $data['condicionIVA'] ?: 'consumidor-final';
$usuario_id = $data['usuario_id'];

// Insertar datos del cliente si no es un cliente ocasional
if ($data['cliente'] !== '-Cliente ocasional-') {
    $stmt = $conn->prepare("INSERT INTO clientes (nombre, direccion, telefono, email, condicion_iva) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $data['cliente'], $data['domicilio'], $data['telefono'], $data['email'], $data['condicionIVA']);
    $stmt->execute();
    $cliente_id = $stmt->insert_id;
    $stmt->close();
} else {
    $cliente_id = NULL;
}

// Insertar datos de la venta y actualizar el stock de los productos
$stmt = $conn->prepare("INSERT INTO ventas (producto, cantidad, precio, descuento, metodo_pago, cliente_id, usuario_id, estado) VALUES (?, ?, ?, ?, ?, ?, ?, 'completada')");
$update_stock_stmt = $conn->prepare("UPDATE articulos SET stock = stock - ? WHERE articulo = ?");

$venta_id = null;
foreach ($data['productos'] as $producto) {
    $stmt->bind_param("siddsii", $producto['articulo'], $producto['cantidad'], $producto['precioUnitario'], $producto['descuentoRecargo'], $data['metodoPago'], $cliente_id, $usuario_id);
    $stmt->execute();
    if ($venta_id === null) {
        $venta_id = $stmt->insert_id;
    }

    // Actualizar el stock del producto
    $update_stock_stmt->bind_param("is", $producto['cantidad'], $producto['articulo']);
    $update_stock_stmt->execute();
}

$stmt->close();
$update_stock_stmt->close();

// Insertar datos de la factura
$stmt = $conn->prepare("INSERT INTO facturas (cliente_id, venta_id, fecha, total) VALUES (?, ?, NOW(), ?)");
$stmt->bind_param("iid", $cliente_id, $venta_id, $data['total']);
$stmt->execute();
$stmt->close();

$conn->close();

echo json_encode(['success' => true]);
?>