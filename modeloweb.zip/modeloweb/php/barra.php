<?php
include("conexion/conexion.php");

// Verificar si se ha enviado el parámetro 'codigo' en la solicitud GET
if (isset($_GET['codigo'])) {
    $codigo = $conn->real_escape_string($_GET['codigo']);

    // Construir la consulta SQL para buscar el artículo por código
    $sql = "SELECT * FROM articulos WHERE codigo = '$codigo'";
    $result = $conn->query($sql);

    // Verificar si se encontró el artículo
    if ($result->num_rows > 0) {
        $articulo = $result->fetch_assoc();
        echo json_encode($articulo);
    } else {
        echo json_encode(null); // No se encontró el artículo
    }
} else {
    echo json_encode(null); // No se recibió el código
}

// Cerrar la conexión a la base de datos
$conn->close();
?>