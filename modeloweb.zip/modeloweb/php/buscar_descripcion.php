<?php
// Conexión a la base de datos
include("conexion/conexion.php");

// Obtener la palabra clave y sanitizar la entrada del usuario
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
$keyword = $conn->real_escape_string($keyword);

// Preparar la consulta SQL
$sql = $conn->prepare("SELECT * FROM articulos WHERE articulo LIKE ? OR codigo LIKE ?");
$searchTerm = "%$keyword%";
$sql->bind_param("ss", $searchTerm, $searchTerm);

// Ejecutar la consulta
$sql->execute();
$result = $sql->get_result();

$productos = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }
}

// Cerrar la conexión y liberar recursos
$sql->close();
$conn->close();

// Devolver la respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($productos);
?>
