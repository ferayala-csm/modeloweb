<?php
require('fpdf/fpdf.php');
include("conexion/conexion.php");

// Desactiva la notificación de errores de índices no definidos
error_reporting(E_ALL & ~E_NOTICE);

// Obtener datos del POST y asignar valores por defecto si están vacíos
$cliente = isset($_POST['cliente']) ? $_POST['cliente'] : '-Cliente ocacional-';
$telefono = isset($_POST['telefono']) ? $_POST['telefono'] : '-';
$domicilio = isset($_POST['domicilio']) ? $_POST['domicilio'] : '-';
$email = isset($_POST['email']) ? $_POST['email'] : '-';
$condicionIVA = isset($_POST['condicionIVA']) ? $_POST['condicionIVA'] : 'consumidor-final';
$fecha = isset($_POST['fecha']) ? $_POST['fecha'] : date('Y-m-d');
$tipoTicket = isset($_POST['tipo-ticket']) ? $_POST['tipo-ticket'] : 'ticket-fiscal';
$numero = isset($_POST['numero']) ? $_POST['numero'] : '-';
$descripcion = isset($_POST['descripcion']) ? $_POST['descripcion'] : '-';
$productos = isset($_POST['productos']) ? json_decode($_POST['productos'], true) : [];
$subtotal = isset($_POST['subtotal']) ? $_POST['subtotal'] : '0.00';
$descuentoRecargo = isset($_POST['descuentoRecargo']) ? $_POST['descuentoRecargo'] : '0.00';
$total = isset($_POST['total']) ? $_POST['total'] : '0.00';

// Crear el PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Datos del cliente
$pdf->Cell(0, 10, 'Vista previa de factura', 0, 1, 'C');
$pdf->Ln(5);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 10, 'Cliente: ' . $cliente, 0, 1);
$pdf->Cell(0, 10, 'Telefono: ' . $telefono, 0, 1);
$pdf->Cell(0, 10, 'Domicilio: ' . $domicilio, 0, 1);
$pdf->Cell(0, 10, 'Email: ' . $email, 0, 1);
$pdf->Cell(0, 10, 'Condicion IVA: ' . $condicionIVA, 0, 1);
$pdf->Cell(0, 10, 'Fecha: ' . $fecha, 0, 1);
$pdf->Cell(0, 10, 'Tipo de Ticket: ' . $tipoTicket, 0, 1);
$pdf->Cell(0, 10, 'Numero: ' . $numero, 0, 1);
$pdf->Cell(0, 10, 'Descripcion: ' . $descripcion, 0, 1);
$pdf->Ln(10);

// Tabla de productos
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(70, 10, 'Articulo', 1);
$pdf->Cell(30, 10, 'Precio', 1);
$pdf->Cell(40, 10, 'Descuento/Recargo', 1);
$pdf->Cell(50, 10, 'Importe', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
foreach ($productos as $producto) {
    $pdf->Cell(70, 10, $producto['articulo'], 1);
    $pdf->Cell(30, 10, $producto['precio_unitario'], 1);
    $pdf->Cell(40, 10, $producto['des_rec'], 1);
    $pdf->Cell(50, 10, $producto['importe'], 1);
    $pdf->Ln();
}

$pdf->Ln(10);

// Total
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(140, 10, 'Subtotal', 1);
$pdf->Cell(50, 10, '$' . $subtotal, 1, 0, 'R');
$pdf->Ln();
$pdf->Cell(140, 10, 'Descuento/Recargo', 1);
$pdf->Cell(50, 10, '$' . $descuentoRecargo, 1, 0, 'R');
$pdf->Ln();
$pdf->Cell(140, 10, 'Total', 1);
$pdf->Cell(50, 10, '$' . $total, 1, 0, 'R');
$pdf->Ln();

// Salida del PDF
$pdf->Output();
?>