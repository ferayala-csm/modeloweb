<?php
// Realizar la conexión a la base de datos (debes incluir aquí tus credenciales de conexión)
include("conexion/conexion.php");
// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$codigo = $_POST['codigo'];
$articulo = $_POST['articulo'];
$pcosto = $_POST['pcosto'];
$pventa = $_POST['pventa'];
$stock = $_POST['stock'];
$minimo = $_POST['minimo'];

// Insertar el nuevo artículo en la base de datos
$sql = "INSERT INTO articulos (codigo, articulo, pcosto, pventa, stock, minimo) VALUES ('$codigo', '$articulo', '$pcosto', '$pventa', '$stock', '$minimo')";

if ($conn->query($sql) === TRUE) {
    echo "Artículo agregado exitosamente";
    
    echo "<script>window.location.href = 'index.php';</script>";
    exit();
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
