<?php
// Establecer el número de artículos por página
$articulos_por_pagina = 20;

// Obtener el número de página actual
$pagina_actual = isset($_GET['pagina']) ? intval($_GET['pagina']) : 1;
$inicio = ($pagina_actual - 1) * $articulos_por_pagina;
include("conexion/conexion.php");
// Realizar la conexión a la base de datos (debes incluir aquí tus credenciales de conexión)
/* $servername = "localhost";
$username = "root";
$password = "";
$database = "prime";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
} */

// Realizar la consulta a la base de datos
$sql = "SELECT * FROM articulos LIMIT $inicio, $articulos_por_pagina";
$result = $conn->query($sql);

// Mostrar los resultados en una tabla
if ($result->num_rows > 0) {
    echo "<h2>Artículos</h2>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Código</th><th>Artículo</th><th>Precio de costo</th><th>Precio de venta</th><th>Stock</th><th>Stock mínimo</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["codigo"] . "</td>";
        echo "<td>" . $row["articulo"] . "</td>";
        echo "<td>" . $row["pcosto"] . "</td>";
        echo "<td>" . $row["pventa"] . "</td>";
        echo "<td>" . $row["stock"] . "</td>";
        echo "<td>" . $row["minimo"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Calcular el número total de páginas
    $sql_total = "SELECT COUNT(*) AS total FROM articulos";
    $result_total = $conn->query($sql_total);
    $fila_total = $result_total->fetch_assoc();
    $total_articulos = $fila_total['total'];
    $total_paginas = ceil($total_articulos / $articulos_por_pagina);

    // Mostrar enlaces para navegar entre las páginas
    echo "<div>";
    if ($pagina_actual > 1) {
        echo "<a href='javascript:void(0)' onclick='cargarArticulos(".($pagina_actual - 1).")'> &nbsp;&nbsp;&nbsp; < </a>";
    }
    if ($pagina_actual < $total_paginas) {
        echo "<a href='javascript:void(0)' onclick='cargarArticulos(".($pagina_actual + 1).")'> > &nbsp;&nbsp;&nbsp; </a>";
    }
    echo "</div>";
} else {
    echo "No se encontraron artículos";
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
