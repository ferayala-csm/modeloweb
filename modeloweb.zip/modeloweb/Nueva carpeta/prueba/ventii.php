<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interfaz Interactiva con Mapa de Imagen</title>
    <style>
        body {
            text-align: center;
            padding: 50px;
        }
        img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Interfaz Interactiva con Mapa de Imagen</h1>
    <img src="pagina.png" usemap="#mapaPagina" alt="Mapa Interactivo">

    <map name="mapaPagina">
        <area shape="rect" coords="34,44,270,350" alt="Area1" href="link1.html">
        <area shape="rect" coords="290,172,333,250" alt="Area2" href="link2.html">
        <area shape="circle" coords="337,300,44" alt="Area3" href="link3.html">
        <area shape="poly" coords="372,298,405,279,425,290,413,327,385,327" alt="Area4" href="link4.html">
    </map>

    <script>
        // Puedes agregar scripts para manejar acciones adicionales
    </script>
</body>
</html>
