<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilos.css">
    
    <title>Realizar Venta - Prime Supermercado</title>
</head>
<body>
    <h1>Realizar Venta</h1>
    <!-- Vista previa del producto seleccionado -->
    <div id="vistaPreviaProducto">
        
        <span id="nombreProducto" class="nombre1"></span>
        <span>-----------</span>
        <span id="precioProducto" class="nombre"></span>
        <span>-----------</span>
        <span id="codigoProducto" class="nombre"></span>
        <span>-</span>
        <span id="idProducto" class="detalle"></span>
        <span>-</span>
        <span id="stockProducto" class="detalle"></span>
    </div>

    <!-- Formulario para realizar la venta -->
    <form id="formVenta" action="ventas.php" method="post">
        <input type="hidden" id="producto" name="producto">
        <input type="hidden" id="precio" name="precio">
        
        <label for="codigo">Producto:</label>
        <input type="text" id="codigo" name="codigo" onblur="buscarArticuloPorCodigo()" oninput="buscarArticuloPorCodigo()">

        <br><br>
        <div id="mensaje"></div>
        <label for="cantidad">Cantidad:</label>
        <input type="number" id="cantidad" name="cantidad" value="1">
        <br><br>
        
        <input type="button" value="Agregar" onclick="agregarProducto()">
    </form>

    <!-- Tabla de productos -->
    <table id="tablaProductos">
        <thead>
            <tr>
                <th>Artículo</th>
                <th>Stock</th>
                <th>Precio unitario</th>
                <th>Cantidad</th>
                <th>Descuento</th>
                <th>Importe</th>
            </tr>
        </thead>
        <tbody id="tbodyProductos">
            <!-- Aquí se cargarán los productos agregados -->
        </tbody>
    </table>

    <!-- Total de la venta -->
    <div id="totalVenta">
    <h2>Total Venta</h2>
    <p>Total Importe: <span id="totalImporte">0.00</span></p>
    <p id="detalleRecargoDescuento" style="display: none;">Descuento/Recargo: <span id="valorRecargoDescuento">0.00</span></p>
    <p id="montoFinal" style="display: none;">Monto Final: <span id="valorMontoFinal">0.00</span></p>
</div>

<div id="formaPago">
    <h3>Forma de Pago</h3>
    <select id="metodoPago" onchange="mostrarOpcionesAdicionales()">
        <option value="efectivo" selected>Efectivo</option>
        <option value="tarjetaDebito">Tarjeta de Débito</option>
        <option value="tarjetaCredito">Tarjeta de Crédito</option>
        <option value="transferencia">Transferencia</option>
        <option value="otro">Otro</option>
    </select>
</div>

<div id="opcionesAdicionales" style="display: none;">
    <h3>Opciones Adicionales</h3>
    <label for="recargoDescuento">Recargo/Descuento (%):</label>
    <input type="number" id="recargoDescuento" name="recargoDescuento" step="0.01">
    <button type="button" onclick="aplicarRecargoDescuento()">Aplicar</button>
</div>

    <!-- Sección de botones vacíos en cuadrícula 5x4 -->
    <div class="botones-vacios">
        <?php
        // Generar botones vacíos
        for ($i = 1; $i <= 20; $i++) {
            echo "<button class='resultado'></button>";
            if ($i % 5 == 0) {
                echo "<br>";
            }
        }
        ?>
    </div>

    <!-- Sección de clasificación de productos en cuadrícula 3x3 -->
    <div class="clasificacion-productos">
        <h2>Clasificación de Productos</h2>
        <div class="grid-3x3">
            <button class="filtro" data-filtro="panes">Panes</button>
            <button class="filtro" data-filtro="verduras">Verduras</button>
            <button class="filtro" data-filtro="frutas">Frutas</button>
            <button class="filtro" data-filtro="lacteos">Lácteos</button>
            <button class="filtro" data-filtro="bebidas">Bebidas</button>
            <button class="filtro" data-filtro="snacks">Snacks</button>
            <button class="filtro" data-filtro="carnes">Carnes</button>
            <button class="filtro" data-filtro="limpieza">Productos de limpieza</button>
            <button class="filtro" data-filtro="cuidado">Productos de cuidado personal</button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
    // Agregar evento clic a cada fila de la tabla para seleccionarla
    const filas = document.querySelectorAll('#tablaProductos tbody tr');
    filas.forEach(function(fila) {
        fila.addEventListener('click', function() {
            seleccionarFila(this);
        });
    });
});
    document.addEventListener('DOMContentLoaded', () => {
        cargarResultados('');
    });

    // Obtener referencia a los botones de clasificación
    const filtros = document.querySelectorAll('.filtro');

    // Manejar el evento de clic en los botones de clasificación
    filtros.forEach(filtro => {
        filtro.addEventListener('click', () => {
            // Obtener el valor del atributo data-filtro del botón
            const filtroValor = filtro.getAttribute('data-filtro');
            console.log("Clic en filtro:", filtroValor);
            // Llamar a la función para cargar los resultados de la búsqueda
            cargarResultados(filtroValor);
        });
    });

    // Función para cargar los resultados de la búsqueda según el filtro
    function cargarResultados(filtro) {
        console.log("Cargar resultados para filtro:", filtro);
        // Hacer una solicitud AJAX para obtener los resultados de la búsqueda
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "buscar_articulos.php?filtro=" + filtro, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                console.log("Respuesta recibida:", xhr.responseText);
                // Parsear la respuesta JSON
                const resultados = JSON.parse(xhr.responseText);
                console.log("Resultados parseados:", resultados);
                // Limpiar el contenido de los botones vacíos
                const botonesVacios = document.querySelectorAll('.botones-vacios .resultado');
                botonesVacios.forEach(boton => {
                    boton.textContent = '';
                    boton.dataset.producto = ''; // Limpiar el dataset
                });
                // Llenar los botones vacíos con los resultados
                resultados.forEach((resultado, index) => {
                    if (index < botonesVacios.length) {
                        botonesVacios[index].textContent = resultado.articulo;
                        botonesVacios[index].dataset.producto = JSON.stringify(resultado); // Guardar el objeto producto en el dataset
                        // Agregar evento clic a cada botón de producto
                        botonesVacios[index].addEventListener('click', function() {
                            mostrarVistaPrevia(resultado);
                        });
                    }
                });
            }
        };
        xhr.send();
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Agregar evento clic a cada fila de la tabla para seleccionarla
        const filas = document.querySelectorAll('#tablaProductos tbody tr');
        filas.forEach(function(fila) {
            fila.addEventListener('click', function() {
                seleccionarFila(this);
            });
        });

        // Agregar evento de tecla para detectar la tecla "Suprimir"
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Delete') {
                eliminarFilaSeleccionada();
            }
        });
    });
    function buscarArticuloPorCodigo() {
    const codigo = document.getElementById('codigo').value.trim();
    if (codigo !== '') {
        // Hacer una solicitud AJAX para buscar el artículo por código
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "barra.php?codigo=" + codigo, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                const producto = JSON.parse(xhr.responseText);
                if (producto) {
                    // Mostrar la vista previa del producto encontrado
                    mostrarVistaPrevia(producto);
                } else {
                    // Limpiar la vista previa si no se encuentra ningún producto
                     // Mostrar el mensaje de "Producto no encontrado" en el elemento <div> con ID "mensaje"
                     document.getElementById('mensaje').textContent = "Producto no encontrado";

                    // Establecer un temporizador para limpiar el contenido del mensaje después de 1 segundo (1000 milisegundos)
                    setTimeout(function() {
                        document.getElementById('mensaje').textContent = "";
                    }, 1000);
                    limpiarVistaPrevia();
                    document.getElementById('codigo').value = '';
                }
            }
        };
        xhr.send();
    }
}

function buscarArticuloPorCodigoEnter(event) {
        if (event.key === 'Enter') {
            const codigo = document.getElementById('codigo').value;
            buscarArticuloPorCodigo(codigo); // Cambiado para pasar el código como parámetro
        }
        }

    // Función para seleccionar una fila
    function seleccionarFila(fila) {
        // Remover la clase 'seleccionada' de todas las filas
        const filas = document.querySelectorAll('#tablaProductos tbody tr');
        filas.forEach(function(fila) {
            fila.classList.remove('seleccionada');
        });

        // Agregar la clase 'seleccionada' a la fila clickeada
        fila.classList.add('seleccionada');
    }

    // Función para eliminar la fila seleccionada
    function eliminarFilaSeleccionada() {
        // Obtener la fila seleccionada
        const filaSeleccionada = document.querySelector('#tablaProductos tbody tr.seleccionada');
        if (filaSeleccionada) {
            // Obtener el importe de la fila
            const importe = parseFloat(filaSeleccionada.cells[5].textContent);

            // Eliminar la fila seleccionada
            filaSeleccionada.remove();

            // Actualizar el total de la venta
            actualizarTotalVenta(-importe);
        }
    }

    // Función para mostrar la vista previa del producto seleccionado
    function mostrarVistaPrevia(producto) {
        document.getElementById('idProducto').textContent = "ID: " + producto.id;
        document.getElementById('codigoProducto').textContent = "Código: " + producto.codigo;
        document.getElementById('nombreProducto').textContent = "Artículo: " + producto.articulo;
        document.getElementById('precioProducto').textContent = "Precio: " + producto.pventa;
        document.getElementById('stockProducto').textContent = "Stock: " + producto.stock;

        document.getElementById('producto').value = producto.articulo;
        document.getElementById('precio').value = producto.pventa;
    }

    // Función para limpiar la vista previa del producto
    function limpiarVistaPrevia() {
        document.getElementById('idProducto').textContent = "";
        document.getElementById('codigoProducto').textContent = "";
        document.getElementById('nombreProducto').textContent = "";
        document.getElementById('precioProducto').textContent = "";
        document.getElementById('stockProducto').textContent = "";

        document.getElementById('producto').value = "";
        document.getElementById('precio').value = "";
    }

    // Función para agregar un producto a la tabla de productos
    function agregarProducto() {
        
        const nombreProducto = document.getElementById('nombreProducto').textContent.split(": ")[1];
        const stockProducto = document.getElementById('stockProducto').textContent.split(": ")[1];
        const precioProductoText = document.getElementById('precioProducto').textContent.split(": ")[1];
        const precioProductoNum = parseFloat(precioProductoText);

        if (isNaN(precioProductoNum)) {
            alert("El precio del producto no es válido.");
            return;
        }

        const cantidad = document.getElementById('cantidad').value;
        if (isNaN(parseInt(cantidad)) || parseInt(cantidad) <= 0) {
            alert("La cantidad ingresada no es válida.");
            return;
        }

        const importe = precioProductoNum * parseInt(cantidad);

        const tabla = document.getElementById('tablaProductos').getElementsByTagName('tbody')[0];
        const nuevaFila = tabla.insertRow();

        const celdaNombre = nuevaFila.insertCell();
        celdaNombre.textContent = nombreProducto;

        const celdaStock = nuevaFila.insertCell();
        celdaStock.textContent = stockProducto;

        const celdaPrecio = nuevaFila.insertCell();
        celdaPrecio.textContent = precioProductoText;

        const celdaCantidad = nuevaFila.insertCell();
        celdaCantidad.textContent = cantidad;

        const celdaDescuento = nuevaFila.insertCell();
        celdaDescuento.textContent = "No";

        const celdaImporte = nuevaFila.insertCell();
        celdaImporte.textContent = importe.toFixed(2);

        const botonEliminar = document.createElement('button');
        botonEliminar.textContent = 'Eliminar';
        botonEliminar.addEventListener('click', function() {
            eliminarProducto(this); // Pasar el botón como referencia al producto a eliminar
        });
                // Agregar el botón a la última celda de la fila
                nuevaFila.insertCell().appendChild(botonEliminar);
        // Actualizar el total de la venta
        actualizarTotalVenta(importe);

        limpiarVistaPrevia();
        document.getElementById('codigo').value = '';
        document.getElementById('cantidad').value = 1;
    }

        function eliminarProducto(botonEliminar) {
        // Obtener la fila actual
        const fila = botonEliminar.closest('tr');

        // Obtener el importe y el descuento/adicional de la fila
        const importe = parseFloat(fila.cells[5].textContent);
        const descuentoAdicional = parseFloat(document.getElementById("recargoDescuento").value);

        // Eliminar la fila de la tabla
        fila.remove();

        // Actualizar el total de la venta
        actualizarTotalVenta(-importe);

        // Actualizar el descuento/adicional
        actualizarDescuentoAdicional(descuentoAdicional);
        }


    // Función para actualizar el total de la venta
    function actualizarTotalVenta(importe) {
    var totalImporteSpan = document.getElementById("totalImporte");
    var totalImporte = parseFloat(totalImporteSpan.textContent);

    // Calcular el nuevo total
    var nuevoTotal = totalImporte + importe;

    // Actualizar el total de la venta
    totalImporteSpan.textContent = nuevoTotal.toFixed(2);
    }
    function aplicarRecargoDescuento() {
    var recargoDescuento = parseFloat(document.getElementById("recargoDescuento").value);
    var totalImporteSpan = document.getElementById("totalImporte");
    var totalImporte = parseFloat(totalImporteSpan.textContent);
    var detalleRecargoDescuento = document.getElementById("detalleRecargoDescuento");
    var valorRecargoDescuento = document.getElementById("valorRecargoDescuento");
    var montoFinal = document.getElementById("montoFinal");
    var valorMontoFinal = document.getElementById("valorMontoFinal");

    if (!isNaN(recargoDescuento)) {
        var recargoDescuentoMonto = totalImporte * recargoDescuento / 100;
        var nuevoTotal = totalImporte + recargoDescuentoMonto;

        // Mostrar el texto "Descuento" si es negativo, "Adicional" si es positivo
        var textoRecargoDescuento = recargoDescuento >= 0 ? "Adicional" : "Descuento";

        // Formatear el texto para el recargo/descuento
        valorRecargoDescuento.textContent = textoRecargoDescuento + ": " + recargoDescuento.toFixed(2) + "% (" + (recargoDescuentoMonto >= 0 ? "+" : "") + recargoDescuentoMonto.toFixed(2) + ")";

        // Actualizar el monto final
        valorMontoFinal.textContent = nuevoTotal.toFixed(2);

        // Mostrar los detalles del recargo/descuento y el monto final
        detalleRecargoDescuento.style.display = "block";
        montoFinal.style.display = "block";
    } else {
        alert("Por favor, ingrese un valor válido para el recargo/descuento.");
    }
}

function mostrarOpcionesAdicionales() {
    var metodoPagoSelect = document.getElementById("metodoPago");
    var opcionesAdicionalesDiv = document.getElementById("opcionesAdicionales");

    if (metodoPagoSelect.value === "tarjetaDebito" || metodoPagoSelect.value === "tarjetaCredito" || metodoPagoSelect.value === "otro") {
        opcionesAdicionalesDiv.style.display = "block";
    } else {
        opcionesAdicionalesDiv.style.display = "none";
    }
}
function actualizarDescuentoAdicional(descuentoAdicional) {
    var valorRecargoDescuento = document.getElementById("valorRecargoDescuento");
    var valorMontoFinal = document.getElementById("valorMontoFinal");

    // Obtener el total importe actualizado
    var totalImporte = parseFloat(document.getElementById("totalImporte").textContent);

    // Calcular el nuevo monto final
    var nuevoMontoFinal = totalImporte + (totalImporte * descuentoAdicional / 100);

    // Actualizar el texto del descuento/adicional
    if (descuentoAdicional >= 0) {
        valorRecargoDescuento.textContent = "Adicional: " + descuentoAdicional.toFixed(2) + "% (" + (totalImporte * descuentoAdicional / 100).toFixed(2) + ")";
    } else {
        valorRecargoDescuento.textContent = "Descuento: " + (-descuentoAdicional).toFixed(2) + "% (" + (totalImporte * descuentoAdicional / 100).toFixed(2) + ")";
    }

    // Actualizar el monto final
    valorMontoFinal.textContent = nuevoMontoFinal.toFixed(2);
}

document.addEventListener("DOMContentLoaded", function() {
    mostrarOpcionesAdicionales();
});



    
</script>

</body>
</html>


