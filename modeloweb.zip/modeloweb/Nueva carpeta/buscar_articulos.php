<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "prime";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el filtro enviado por la solicitud AJAX
$filtro = isset($_GET["filtro"]) ? $_GET["filtro"] : '';

if (empty($filtro)) {
    echo json_encode([]);
    $conn->close();
    exit();
}

// Palabras relacionadas a cada categoría
$palabras_relacionadas = array(
    "panes" => array("pan", "masa", "harina"),
    "verduras" => array("perejil", "cebolla", "papa", "apio", "aji"),
    "frutas" => array("pera", "mandarina", "piña", "manzana", "banana"),
    "lacteos" => array("leche", "queso", "yogurt", "dulce", "crema"),
    "bebidas" => array("bebida", "refresco", "soda", "agua", "gaseosa", "coca", "sprite", "cerveza"),
    "snacks" => array("snack", "aperitivo", "patatas", "galleta", "surtido"),
    "carnes" => array("carne", "pollo", "cerdo", "res", "pescado"),
    "limpieza" => array("limpieza", "detergente", "jabon", "toalla"),
    "cuidado" => array("cuidado", "champu", "jabon", "crema")
);

// Obtener palabras relacionadas al filtro
$palabras_relacionadas_filtro = isset($palabras_relacionadas[$filtro]) ? $palabras_relacionadas[$filtro] : [];

if (empty($palabras_relacionadas_filtro)) {
    echo json_encode([]);
    $conn->close();
    exit();
}

// Construir la parte WHERE de la consulta SQL
$where = "";
foreach ($palabras_relacionadas_filtro as $palabra) {
    $where .= "articulo LIKE '%$palabra%' OR ";
}
$where = rtrim($where, " OR ");

// Consulta SQL para buscar los artículos similares
$sql = "SELECT id,codigo, articulo, pventa, stock FROM articulos WHERE $where LIMIT 20";

// Ejecutar la consulta SQL
$resultado = $conn->query($sql);
$articulos = array();
if ($resultado && $resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        $articulo = array(
            "id" => $fila["id"], // Agregar el ID del producto
            "codigo" => $fila["codigo"],
            "articulo" => $fila["articulo"], // Corregido a "articulo" en vez de "producto"
            "pventa" => $fila["pventa"],
            "stock" => $fila["stock"]
        );
        array_push($articulos, $articulo);
    }
}


echo json_encode($articulos);

$conn->close();
?>
