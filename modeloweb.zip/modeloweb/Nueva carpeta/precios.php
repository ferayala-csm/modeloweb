<?php
include 'conexion/conexion.php'; // Asegúrate de que la conexión esté configurada correctamente

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['porcentaje'])) {
    $porcentaje = floatval($_POST['porcentaje']);

    // Validar que el porcentaje no sea nulo
    if ($porcentaje == 0) {
        echo "Porcentaje inválido.";
        exit;
    }

    // Actualizar los precios en la base de datos
    $sql = "UPDATE articulos SET pventa = pventa + (pventa * ? / 100)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo "Error en la preparación de la declaración: " . $conn->error;
        exit;
    }

    $stmt->bind_param("d", $porcentaje);

    if ($stmt->execute()) {
        echo "Precios actualizados exitosamente.";
    } else {
        echo "Error al actualizar los precios: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Solicitud no válida.";
}
?>

