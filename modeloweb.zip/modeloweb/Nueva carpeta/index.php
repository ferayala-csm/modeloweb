<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prime Supermercado</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("logo").addEventListener("click", function() {
                window.location.href = "index.php"; // Cambia "index.php" a la página a la que deseas redirigir
            });
        });

        function mostrarSeccion(seccion) {
            document.getElementById('seccionArticulos').style.display = 'none';
            document.getElementById(seccion).style.display = 'block';
            if (seccion === 'seccionArticulos') {
                document.getElementById('btnAgregarArticulo').style.display = 'inline-block';
            } else {
                document.getElementById('btnAgregarArticulo').style.display = 'none';
            }
        }

        function cargarArticulos(pagina = 1) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "cargar_articulos.php?pagina=" + pagina, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById("listaArticulos").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }

        function buscarArticulos() {
            var busqueda = document.getElementById("busqueda").value;
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "filtrar_articulos.php?busqueda=" + busqueda, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById("listaArticulos").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }
        function actualizarPrecios() {
        var porcentaje = document.getElementById('porcentaje').value;
        if (!porcentaje) {
            alert("Por favor, ingrese un porcentaje.");
            return;
        }
        
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "precios.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                alert(xhr.responseText);
                cargarArticulos(); // Recargar la lista de artículos para reflejar los cambios
            }
        };
        
        xhr.send("porcentaje=" + encodeURIComponent(porcentaje));
        }


        function abrirModal() {
            document.getElementById('modalAgregar').style.display = 'block';
        }

        function cerrarModal() {
            document.getElementById('modalAgregar').style.display = 'none';
        }
    </script>
    <style>
        .hidden {
            display: none;
        }

        /* Estilos para el modal */
        .modal {
            display: none; /* Oculto por defecto */
            position: fixed; /* Fijo en pantalla */
            z-index: 1; /* Por encima de todo el contenido */
            left: 0;
            top: 0;
            width: 100%; /* Ancho total */
            height: 100%; /* Alto total */
            overflow: auto; /* Habilita el scroll si es necesario */
            background-color: rgb(0,0,0.); /* Color de fondo */
            background-color: rgba(0,0,0,0.4); /* Fondo con opacidad */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* Centrado vertical y horizontal */
            padding: 20px;
            border: 1px solid #888;
            width: 70%; /* Ancho de la ventana modal */
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Botones para mostrar las secciones -->
    <div class="header">
    <img id="logo" src="media/logo.png" alt="Logo">
    <div class="button-container">
        <button onclick="mostrarSeccion('seccionArticulos'); cargarArticulos()">Artículos</button>
        <button onclick="location.href = 'ventas.php';">Ventas</button>
        <!-- Aquí puedes agregar futuros botones -->
    </div>
</div>

    <!-- Sección para mostrar la lista de artículos existentes -->
    <div id="seccionArticulos" class="hidden">
        <h2>Buscar Artículos</h2>
        <input type="text" id="busqueda" onkeyup="buscarArticulos()" placeholder="Buscar artículos por nombre o código">
        <button id="btnAgregarArticulo" class="hidden" onclick="abrirModal()">Agregar Artículo</button>
        <div class="inline-container">
        <input type="number" id="porcentaje" name="porcentaje" placeholder="Porcentaje" step="0.01" required>
        <button type="button" onclick="actualizarPrecios()">Actualizar Precios</button>
        </div>
        <div id="listaArticulos"></div>
        
    </div>

    

    <!-- Modal para agregar un nuevo artículo -->
    <div id="modalAgregar" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarModal()">&times;</span>
            <h2>Agregar nuevo artículo</h2>
            <form action="agregar_articulo.php" method="post">
                <label for="codigo">Código:</label>
                <input type="text" id="codigo" name="codigo"><br><br>

                <label for="articulo">Artículo:</label>
                <input type="text" id="articulo" name="articulo"><br><br>

                <label for="pcosto">Precio de costo:</label>
                <input type="text" id="pcosto" name="pcosto"><br><br>

                <label for="pventa">Precio de venta:</label>
                <input type="text" id="pventa" name="pventa"><br><br>

                <label for="stock">Stock:</label>
                <input type="text" id="stock" name="stock"><br><br>

                <label for="minimo">Stock mínimo:</label>
                <input type="text" id="minimo" name="minimo"><br><br>

                <input type="submit" value="Agregar">
            </form>
        </div>
    </div>
</body>
</html>
