<?php
require('fpdf/fpdf.php');
include("conexion/conexion.php");

if (isset($_POST['venta_id'])) {
    $venta_id = $_POST['venta_id'];

    // Obtener datos de la venta
    $consulta_venta = "SELECT * FROM ventas WHERE id = ?";
    $stmt = $conn->prepare($consulta_venta);
    $stmt->bind_param("i", $venta_id);
    $stmt->execute();
    $resultado_venta = $stmt->get_result();

    if ($resultado_venta->num_rows === 0) {
        die('No se encontró una venta con el ID proporcionado.');
    }

    $venta = $resultado_venta->fetch_assoc();

    // Obtener datos de los productos de la venta
    $consulta_productos = "SELECT * FROM articulos WHERE venta_id = ?";
    $stmt = $conn->prepare($consulta_productos);
    $stmt->bind_param("i", $venta_id);
    $stmt->execute();
    $resultado_productos = $stmt->get_result();
    $productos = $resultado_productos->fetch_all(MYSQLI_ASSOC);

    // Crear el PDF del comprobante
    $pdf = new FPDF();
    $pdf->AddPage();

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Comprobante de Venta', 0, 1, 'C');

    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 10, 'Venta ID: ' . $venta['id'], 0, 1);
    $pdf->Cell(0, 10, 'Fecha: ' . $venta['fecha'], 0, 1);

    // Datos del cliente
    if ($venta['cliente_id']) {
        $consulta_cliente = "SELECT * FROM clientes WHERE id = ?";
        $stmt = $conn->prepare($consulta_cliente);
        $stmt->bind_param("i", $venta['cliente_id']);
        $stmt->execute();
        $resultado_cliente = $stmt->get_result();

        if ($resultado_cliente->num_rows > 0) {
            $cliente = $resultado_cliente->fetch_assoc();

            $pdf->Cell(0, 10, 'Cliente: ' . $cliente['nombre'], 0, 1);
            $pdf->Cell(0, 10, 'Teléfono: ' . $cliente['telefono'], 0, 1);
            $pdf->Cell(0, 10, 'Domicilio: ' . $cliente['domicilio'], 0, 1);
            $pdf->Cell(0, 10, 'Email: ' . $cliente['email'], 0, 1);
        } else {
            $pdf->Cell(0, 10, 'Cliente: No especificado', 0, 1);
        }
    } else {
        $pdf->Cell(0, 10, 'Cliente: ' . $venta['cliente'], 0, 1);
        $pdf->Cell(0, 10, 'Teléfono: ' . $venta['telefono'], 0, 1);
        $pdf->Cell(0, 10, 'Domicilio: ' . $venta['domicilio'], 0, 1);
        $pdf->Cell(0, 10, 'Email: ' . $venta['email'], 0, 1);
    }

    // Detalle de productos
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(40, 10, 'Artículo', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Precio Unitario', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Cantidad', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Desc/Rec', 1, 0, 'C');
    $pdf->Cell(40, 10, 'Importe', 1, 1, 'C');

    $pdf->SetFont('Arial', '', 10);
    foreach ($productos as $producto) {
        $pdf->Cell(40, 10, utf8_decode($producto['articulo']), 1, 0, 'L');
        $pdf->Cell(30, 10, '$' . number_format($producto['precioUnitario'], 2), 1, 0, 'R');
        $pdf->Cell(30, 10, $producto['cantidad'], 1, 0, 'C');
        $pdf->Cell(30, 10, $producto['descuentoRecargo'] . '%', 1, 0, 'C');
        $pdf->Cell(40, 10, '$' . number_format($producto['importe'], 2), 1, 1, 'R');
    }

    // Total
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(130, 10, 'Total', 1, 0, 'R');
    $pdf->Cell(40, 10, '$' . number_format($venta['total'], 2), 1, 1, 'R');

    $pdf->Output('I', 'ComprobanteVenta.pdf'); // Mostrar en el navegador como PDF
}
?>
